# 市場證據結果 (Market Evidence Result)

**整體狀態**: ✅ 完整成功
**結果 ID**: `umeresult-v3-5520f05019453f275a33`
**請求 ID**: `i1-bounded-live-f114b65a619240c69ac7039dc50d52d6`
**生成時間**: 2026-09-30T01:56:48Z

## 請求摘要
- **執行模式**: execute
- **目標數量**: 4
- **請求的資料需求**: market_state_context

## 目標 1
- **解析狀態**: ✅ 已解析
- **規範目標 ID**: `TWSE:1101`
- **證券代碼**: 1101
- **證券名稱**: 台泥
- **市場**: TWSE
- **查詢參考**: TWSE:1101
- **已提供資料需求**: market_state_context

### 證據

### 引用來源
- `cite-201d81a7d903eddd` — 來源: phase_i_i1_market_state_executor | 擷取時間: 2026-09-30T01:56:48Z | 參考: `evidence/phase_i/i1/umeop-op-v1-b332ac23465f81e16bf5.json`

## 目標 2
- **解析狀態**: ✅ 已解析
- **規範目標 ID**: `TWSE:1102`
- **證券代碼**: 1102
- **證券名稱**: 亞泥
- **市場**: TWSE
- **查詢參考**: TWSE:1102
- **已提供資料需求**: market_state_context

### 證據

### 引用來源
- `cite-b67b266a35d33132` — 來源: phase_i_i1_market_state_executor | 擷取時間: 2026-09-30T01:56:48Z | 參考: `evidence/phase_i/i1/umeop-op-v1-edbc03357dd583885f4e.json`

## 目標 3
- **解析狀態**: ✅ 已解析
- **規範目標 ID**: `TPEX:1240`
- **證券代碼**: 1240
- **證券名稱**: 茂生農經
- **市場**: TPEX
- **查詢參考**: TPEX:1240
- **已提供資料需求**: market_state_context

### 證據

### 引用來源
- `cite-06890a0a3ed0f62a` — 來源: phase_i_i1_market_state_executor | 擷取時間: 2026-09-30T01:56:48Z | 參考: `evidence/phase_i/i1/umeop-op-v1-80d51bf6899805d7ed2e.json`

## 目標 4
- **解析狀態**: ✅ 已解析
- **規範目標 ID**: `TPEX:1259`
- **證券代碼**: 1259
- **證券名稱**: 安心
- **市場**: TPEX
- **查詢參考**: TPEX:1259
- **已提供資料需求**: market_state_context

### 證據

### 引用來源
- `cite-3566b1fad3bff4ba` — 來源: phase_i_i1_market_state_executor | 擷取時間: 2026-09-30T01:56:48Z | 參考: `evidence/phase_i/i1/umeop-op-v1-1172781d2a7ba65b7a84.json`

## 審計包參考
- **審計包 ID**: `umeap-v3-b46c0ae2ff773668a93c`
- **相對路徑**: `audit/unified_market_evidence_audit_package.v3.json`

> ℹ️ 審計包 (`unified_market_evidence_audit_package.v3`) 包含完整作業系譜、人工製品清單、引用對應表與重播說明。審計包與 AI 對話結果分開保存。

---
> ℹ️ 本結果由確定性投影層 (M8R-05C) 生成，僅呈現已驗證事實、覆蓋範圍、時間基礎與解讀護欄。